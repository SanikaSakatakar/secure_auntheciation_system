"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import { ArrowRight, Shield, Zap, Lock } from "lucide-react"
import { useEffect, useState } from "react"

export default function Home() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    const loggedIn = localStorage.getItem("isLoggedIn")
    if (loggedIn) {
      setIsLoggedIn(true)
    }
  }, [])

  const fadeInUp = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  }

  const container = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  }

  return (
    <div className="min-h-screen relative overflow-hidden" style={{ backgroundColor: "#0a0e27" }}>
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          className="absolute w-96 h-96 rounded-full blur-3xl"
          animate={{ y: [0, 60, 0], x: [0, 40, 0] }}
          transition={{ duration: 20, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
          style={{
            top: "-150px",
            left: "-150px",
            background: "linear-gradient(135deg, rgba(109, 92, 255, 0.2), rgba(0, 212, 255, 0.2))",
          }}
        />
        <motion.div
          className="absolute w-96 h-96 rounded-full blur-3xl"
          animate={{ y: [60, 0, 60], x: [40, 0, 40] }}
          transition={{ duration: 20, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut", delay: 3 }}
          style={{
            bottom: "-150px",
            right: "-150px",
            background: "linear-gradient(135deg, rgba(255, 0, 110, 0.2), rgba(131, 56, 236, 0.2))",
          }}
        />
        <motion.div
          className="absolute w-96 h-96 rounded-full blur-3xl"
          animate={{ y: [0, -60, 0], x: [-40, 0, -40] }}
          transition={{ duration: 20, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut", delay: 1.5 }}
          style={{
            top: "50%",
            right: "10%",
            background: "linear-gradient(135deg, rgba(0, 212, 255, 0.1), rgba(109, 92, 255, 0.1))",
          }}
        />
      </div>

      {/* Navigation */}
      {mounted && (
        <motion.header
          className="absolute top-0 left-0 right-0 px-6 py-6 relative z-10"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6 }}
        >
          <div className="max-w-7xl mx-auto flex justify-between items-center">
            <motion.h1 className="text-3xl font-bold gradient-text" whileHover={{ scale: 1.05 }}>
              SecureAuth
            </motion.h1>
            <div className="flex gap-4">
              {isLoggedIn ? (
                <Link
                  href="/dashboard"
                  className="text-lg font-semibold transition-all"
                  style={{ color: "rgb(0, 212, 255)" }}
                >
                  Dashboard
                </Link>
              ) : (
                <>
                  <motion.div whileHover={{ y: -2 }}>
                    <Link
                      href="/login"
                      className="text-lg font-semibold transition-all"
                      style={{ color: "rgba(0, 212, 255, 0.8)" }}
                    >
                      Log in
                    </Link>
                  </motion.div>
                  <motion.div whileHover={{ y: -3 }} whileTap={{ scale: 0.95 }}>
                    <Link href="/register" className="btn-primary px-6 py-2 inline-flex items-center gap-2">
                      Sign up
                    </Link>
                  </motion.div>
                </>
              )}
            </div>
          </div>
        </motion.header>
      )}

      {/* Hero Section */}
      <motion.main
        className="max-w-5xl mx-auto text-center mt-32 px-6 relative z-10"
        variants={container}
        initial="hidden"
        animate="visible"
      >
        <motion.div variants={fadeInUp} className="space-y-8 mb-16">
          <h2 className="text-6xl md:text-7xl font-bold text-white leading-tight text-balance">
            Secure your digital
            <br />
            <span className="gradient-text">identity</span>
          </h2>
          <p className="text-xl md:text-2xl opacity-80 max-w-3xl mx-auto leading-relaxed text-white">
            A modern authentication system built with cutting-edge security. Fast, reliable, and ready for your next
            project.
          </p>
        </motion.div>

        {/* CTA Buttons */}
        <motion.div variants={fadeInUp} className="flex flex-col sm:flex-row gap-6 justify-center mb-24">
          {!isLoggedIn && (
            <motion.div whileHover={{ y: -4 }} whileTap={{ scale: 0.95 }}>
              <Link
                href="/register"
                className="btn-primary px-10 py-4 inline-flex items-center justify-center gap-3 text-lg font-semibold rounded-lg"
              >
                Sign up
                <ArrowRight size={24} />
              </Link>
            </motion.div>
          )}
          <motion.div whileHover={{ y: -4 }} whileTap={{ scale: 0.95 }}>
            <Link
              href={isLoggedIn ? "/dashboard" : "/login"}
              className="px-10 py-4 rounded-lg font-semibold border transition-all inline-flex items-center justify-center gap-3 text-lg backdrop-blur-sm"
              style={{
                borderColor: "rgba(0, 212, 255, 0.6)",
                color: "rgb(0, 212, 255)",
                backgroundColor: "rgba(0, 212, 255, 0.12)",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = "rgba(0, 212, 255, 0.2)"
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = "rgba(0, 212, 255, 0.12)"
              }}
            >
              {isLoggedIn ? "Go to Dashboard" : "Already have an account?"}
            </Link>
          </motion.div>
        </motion.div>

        {/* Features */}
        <motion.div variants={fadeInUp} className="grid md:grid-cols-3 gap-8">
          {[
            {
              icon: Shield,
              title: "Secure",
              desc: "Industry-standard encryption protects your data",
              color: "rgb(0, 212, 255)",
            },
            {
              icon: Zap,
              title: "Lightning Fast",
              desc: "Instant authentication with optimized performance",
              color: "rgb(109, 92, 255)",
            },
            {
              icon: Lock,
              title: "Reliable",
              desc: "Robust security with modern best practices",
              color: "rgb(255, 0, 110)",
            },
          ].map((feature, i) => {
            const Icon = feature.icon
            return (
              <motion.div
                key={i}
                className="card p-8 group cursor-default"
                whileHover={{ y: -8, scale: 1.02 }}
                transition={{ duration: 0.3 }}
              >
                <div
                  className="w-14 h-14 rounded-lg flex items-center justify-center mb-6 group-hover:scale-110 transition-transform"
                  style={{
                    background: `linear-gradient(135deg, ${feature.color}22, ${feature.color}11)`,
                  }}
                >
                  <Icon size={28} style={{ color: feature.color }} />
                </div>
                <h3 className="text-xl font-bold text-white mb-3">{feature.title}</h3>
                <p style={{ color: "rgba(255, 255, 255, 0.7)" }}>{feature.desc}</p>
              </motion.div>
            )
          })}
        </motion.div>
      </motion.main>
    </div>
  )
}
