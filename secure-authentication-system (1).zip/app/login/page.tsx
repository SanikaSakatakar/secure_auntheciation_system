"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import Link from "next/link"
import { Eye, EyeOff, Loader, AlertCircle } from "lucide-react"
import { toast, Toaster } from "react-hot-toast"
import { useRouter } from "next/navigation"

interface LoginFormData {
  email: string
  password: string
}

export default function Login() {
  const router = useRouter()
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({})
  const [formData, setFormData] = useState<LoginFormData>({
    email: "",
    password: "",
  })
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  const validateForm = (): boolean => {
    const errors: Record<string, string> = {}

    if (!formData.email.trim()) {
      errors.email = "Email is required"
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      errors.email = "Please enter a valid email"
    }

    if (!formData.password) {
      errors.password = "Password is required"
    }

    setFieldErrors(errors)
    return Object.keys(errors).length === 0
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
    if (fieldErrors[name]) {
      setFieldErrors((prev) => ({
        ...prev,
        [name]: "",
      }))
    }
  }

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()

    if (!validateForm()) {
      return
    }

    setLoading(true)

    try {
      const users = JSON.parse(localStorage.getItem("users") || "[]")

      const user = users.find((u: LoginFormData) => u.email === formData.email && u.password === formData.password)

      if (!user) {
        toast.error("Invalid email or password. Please try again.", {
          duration: 4000,
          icon: <AlertCircle className="w-5 h-5" />,
        })
        setLoading(false)
        return
      }

      // Simulate API delay
      await new Promise((resolve) => setTimeout(resolve, 800))

      localStorage.setItem("isLoggedIn", "true")
      localStorage.setItem("currentUser", JSON.stringify(user))
      localStorage.setItem("token", "authenticated") // for middleware compatibility

      toast.success("Welcome back! Redirecting to dashboard...", {
        duration: 2000,
      })

      // Direct redirect without delay
      window.location.href = "/dashboard"
    } catch (error: any) {
      console.log("[v0] Login error:", error)
      toast.error("Login failed. Please try again.", {
        duration: 4000,
        icon: <AlertCircle className="w-5 h-5" />,
      })
    } finally {
      setLoading(false)
    }
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
        delayChildren: 0.3,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6, ease: "easeOut" },
    },
  }

  if (!mounted) return null

  return (
    <div
      className="min-h-screen flex items-center justify-center px-4 py-8 relative overflow-hidden"
      style={{ backgroundColor: "#0a0e27" }}
    >
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          className="absolute w-96 h-96 rounded-full blur-3xl"
          animate={{ y: [0, 60, 0], x: [0, 40, 0] }}
          transition={{ duration: 20, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
          style={{
            top: "-150px",
            left: "-150px",
            background: "linear-gradient(135deg, rgba(109, 92, 255, 0.2), rgba(0, 212, 255, 0.2))",
          }}
        />
        <motion.div
          className="absolute w-96 h-96 rounded-full blur-3xl"
          animate={{ y: [60, 0, 60], x: [40, 0, 40] }}
          transition={{ duration: 20, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut", delay: 3 }}
          style={{
            bottom: "-150px",
            right: "-150px",
            background: "linear-gradient(135deg, rgba(255, 0, 110, 0.2), rgba(131, 56, 236, 0.2))",
          }}
        />
        <motion.div
          className="absolute w-96 h-96 rounded-full blur-3xl"
          animate={{ y: [0, -60, 0], x: [-40, 0, -40] }}
          transition={{ duration: 20, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut", delay: 1.5 }}
          style={{
            top: "50%",
            right: "10%",
            background: "linear-gradient(135deg, rgba(0, 212, 255, 0.1), rgba(109, 92, 255, 0.1))",
          }}
        />
      </div>

      <Toaster position="top-center" reverseOrder={false} />

      <motion.div
        className="w-full max-w-md relative z-10"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.div
          className="absolute -top-16 right-0"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
        >
          <Link
            href="/"
            className="text-sm font-semibold px-4 py-2 rounded-lg transition-all border"
            style={{
              borderColor: "rgba(0, 212, 255, 0.4)",
              color: "rgb(0, 212, 255)",
              backgroundColor: "rgba(0, 212, 255, 0.08)",
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = "rgba(0, 212, 255, 0.16)"
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = "rgba(0, 212, 255, 0.08)"
            }}
          >
            ← Back to Home
          </Link>
        </motion.div>

        <motion.div variants={itemVariants} className="text-center mb-10">
          <motion.div
            className="inline-block mb-6"
            whileHover={{ scale: 1.08 }}
            whileTap={{ scale: 0.95 }}
            animate={{ y: [0, -5, 0] }}
            transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY }}
          >
            <Link href="/" className="text-4xl font-bold gradient-text hover:opacity-80 transition-opacity">
              SecureAuth
            </Link>
          </motion.div>
          <h2 className="text-5xl font-bold text-white mb-3 text-balance">Welcome Back</h2>
          <p style={{ color: "rgba(0, 212, 255, 0.8)" }} className="text-lg">
            Don't have an account?{" "}
            <Link
              href="/register"
              className="font-bold hover:text-white underline underline-offset-3 transition-colors"
              style={{ color: "rgb(0, 212, 255)" }}
            >
              Sign up
            </Link>
          </p>
        </motion.div>

        <motion.form variants={itemVariants} className="card p-8 space-y-6" onSubmit={handleSubmit}>
          {/* Email Field */}
          <motion.div whileHover={{ y: -2 }} transition={{ duration: 0.3 }}>
            <label
              className="block text-sm font-semibold mb-3 uppercase tracking-wide"
              style={{ color: "rgb(0, 212, 255)" }}
            >
              Email Address
            </label>
            <motion.input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              className={`input-field ${fieldErrors.email ? "ring-2" : ""}`}
              style={
                fieldErrors.email ? { borderColor: "rgb(255, 0, 110)", boxShadow: "0 0 0 2px rgb(255, 0, 110)" } : {}
              }
              placeholder="you@example.com"
              disabled={loading}
              whileFocus={{ scale: 1.02 }}
            />
            <AnimatePresence>
              {fieldErrors.email && (
                <motion.p
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="mt-2 text-sm flex items-center gap-2 font-medium"
                  style={{ color: "rgb(255, 0, 110)" }}
                >
                  <AlertCircle size={16} /> {fieldErrors.email}
                </motion.p>
              )}
            </AnimatePresence>
          </motion.div>

          {/* Password Field */}
          <motion.div whileHover={{ y: -2 }} transition={{ duration: 0.3 }}>
            <div className="flex items-center justify-between mb-3">
              <label
                className="block text-sm font-semibold uppercase tracking-wide"
                style={{ color: "rgb(0, 212, 255)" }}
              >
                Password
              </label>
              <Link
                href="/forgot-password"
                className="text-xs font-bold transition-colors hover:text-white"
                style={{ color: "rgb(0, 212, 255)" }}
              >
                Forgot?
              </Link>
            </div>
            <div className="relative">
              <motion.input
                type={showPassword ? "text" : "password"}
                name="password"
                value={formData.password}
                onChange={handleChange}
                className={`input-field pr-12 ${fieldErrors.password ? "ring-2" : ""}`}
                style={
                  fieldErrors.password
                    ? { borderColor: "rgb(255, 0, 110)", boxShadow: "0 0 0 2px rgb(255, 0, 110)" }
                    : {}
                }
                placeholder="Enter your password"
                disabled={loading}
                whileFocus={{ scale: 1.02 }}
              />
              <motion.button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-4 top-1/2 -translate-y-1/2 hover:text-white transition-colors"
                style={{ color: "rgb(0, 212, 255)" }}
                disabled={loading}
                whileHover={{ scale: 1.2 }}
                whileTap={{ scale: 0.9 }}
              >
                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
              </motion.button>
            </div>
            <AnimatePresence>
              {fieldErrors.password && (
                <motion.p
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="mt-2 text-sm flex items-center gap-2 font-medium"
                  style={{ color: "rgb(255, 0, 110)" }}
                >
                  <AlertCircle size={16} /> {fieldErrors.password}
                </motion.p>
              )}
            </AnimatePresence>
          </motion.div>

          {/* Submit Button */}
          <motion.button
            type="submit"
            disabled={loading}
            className="btn-primary w-full inline-flex items-center justify-center gap-2 mt-8 text-lg"
            whileHover={{ y: -3, scale: 1.02 }}
            whileTap={{ scale: 0.95 }}
          >
            {loading ? (
              <>
                <Loader size={20} className="spinner" />
                Signing in...
              </>
            ) : (
              "Sign In"
            )}
          </motion.button>
        </motion.form>

        <motion.p
          variants={itemVariants}
          className="text-center text-sm mt-8 font-medium"
          style={{ color: "rgba(0, 212, 255, 0.6)" }}
        >
          Your data is protected with industry-standard encryption
        </motion.p>
      </motion.div>
    </div>
  )
}
