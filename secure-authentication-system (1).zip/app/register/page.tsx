"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import Link from "next/link"
import { Eye, EyeOff, Loader, AlertCircle, CheckCircle2, Mail } from "lucide-react"
import { toast, Toaster } from "react-hot-toast"
import { useRouter } from "next/navigation"

interface RegisterData {
  name: string
  email: string
  password: string
  emailVerified?: boolean
}

export default function Register() {
  const router = useRouter()
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({})
  const [step, setStep] = useState<"register" | "verify">("register")
  const [verificationCode, setVerificationCode] = useState("")
  const [generatedCode, setGeneratedCode] = useState("")
  const [registeredEmail, setRegisteredEmail] = useState("")
  const [formData, setFormData] = useState<RegisterData>({
    name: "",
    email: "",
    password: "",
    emailVerified: false,
  })
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  const validateForm = (): boolean => {
    const errors: Record<string, string> = {}

    if (!formData.name.trim()) {
      errors.name = "Full name is required"
    } else if (formData.name.trim().length < 2) {
      errors.name = "Name must be at least 2 characters"
    }

    if (!formData.email.trim()) {
      errors.email = "Email is required"
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      errors.email = "Please enter a valid email"
    }

    if (!formData.password) {
      errors.password = "Password is required"
    } else if (formData.password.length < 6) {
      errors.password = "Password must be at least 6 characters"
    }

    setFieldErrors(errors)
    return Object.keys(errors).length === 0
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
    if (fieldErrors[name]) {
      setFieldErrors((prev) => ({
        ...prev,
        [name]: "",
      }))
    }
  }

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()

    if (!validateForm()) {
      return
    }

    setLoading(true)

    try {
      const users = JSON.parse(localStorage.getItem("users") || "[]")

      const userExists = users.some((u: RegisterData) => u.email === formData.email)
      if (userExists) {
        toast.error("Email already registered. Please use another email or login.", {
          duration: 4000,
          icon: <AlertCircle className="w-5 h-5" />,
        })
        setLoading(false)
        return
      }

      const code = Math.random().toString(36).substring(2, 8).toUpperCase()
      setGeneratedCode(code)
      setRegisteredEmail(formData.email)

      await new Promise((resolve) => setTimeout(resolve, 800))

      toast.success("Verification code sent to your email", {
        duration: 2000,
        icon: <CheckCircle2 className="w-5 h-5" />,
      })

      setStep("verify")
    } catch (error: any) {
      console.log("[v0] Registration error:", error)
      toast.error("Registration failed. Please try again.", {
        duration: 4000,
        icon: <AlertCircle className="w-5 h-5" />,
      })
    } finally {
      setLoading(false)
    }
  }

  const handleVerification = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const errors: Record<string, string> = {}

    if (!verificationCode.trim()) {
      errors.code = "Verification code is required"
    } else if (verificationCode !== generatedCode) {
      errors.code = "Invalid verification code"
    }

    setFieldErrors(errors)
    if (Object.keys(errors).length > 0) return

    setLoading(true)

    try {
      await new Promise((resolve) => setTimeout(resolve, 600))

      const users = JSON.parse(localStorage.getItem("users") || "[]")

      const newUser: RegisterData = {
        ...formData,
        emailVerified: true,
      }

      users.push(newUser)
      localStorage.setItem("users", JSON.stringify(users))

      localStorage.setItem("isLoggedIn", "true")
      localStorage.setItem("currentUser", JSON.stringify(newUser))
      localStorage.setItem("token", "authenticated")

      toast.success("Email verified! Redirecting to dashboard...", {
        duration: 2000,
        icon: <CheckCircle2 className="w-5 h-5" />,
      })

      window.location.href = "/dashboard"
    } catch (error: any) {
      console.log("[v0] Verification error:", error)
      toast.error("Verification failed. Please try again.", {
        duration: 4000,
        icon: <AlertCircle className="w-5 h-5" />,
      })
    } finally {
      setLoading(false)
    }
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
        delayChildren: 0.3,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6, ease: "easeOut" },
    },
  }

  if (!mounted) return null

  return (
    <div
      className="min-h-screen flex items-center justify-center px-4 py-8 relative overflow-hidden"
      style={{ backgroundColor: "#0a0e27" }}
    >
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          className="absolute w-96 h-96 rounded-full blur-3xl"
          animate={{ y: [0, 60, 0], x: [0, 40, 0] }}
          transition={{ duration: 20, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
          style={{
            top: "-150px",
            left: "-150px",
            background: "linear-gradient(135deg, rgba(109, 92, 255, 0.2), rgba(0, 212, 255, 0.2))",
          }}
        />
        <motion.div
          className="absolute w-96 h-96 rounded-full blur-3xl"
          animate={{ y: [60, 0, 60], x: [40, 0, 40] }}
          transition={{ duration: 20, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut", delay: 3 }}
          style={{
            bottom: "-150px",
            right: "-150px",
            background: "linear-gradient(135deg, rgba(255, 0, 110, 0.2), rgba(131, 56, 236, 0.2))",
          }}
        />
      </div>

      <Toaster position="top-center" reverseOrder={false} />

      <motion.div
        className="w-full max-w-md relative z-10"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.div
          className="absolute -top-16 right-0"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
        >
          <Link
            href="/"
            className="text-sm font-semibold px-4 py-2 rounded-lg transition-all border"
            style={{
              borderColor: "rgba(0, 212, 255, 0.4)",
              color: "rgb(0, 212, 255)",
              backgroundColor: "rgba(0, 212, 255, 0.08)",
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = "rgba(0, 212, 255, 0.16)"
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = "rgba(0, 212, 255, 0.08)"
            }}
          >
            ← Back to Home
          </Link>
        </motion.div>

        <motion.div variants={itemVariants} className="text-center mb-10">
          <motion.div
            className="inline-block mb-6"
            whileHover={{ scale: 1.08 }}
            whileTap={{ scale: 0.95 }}
            animate={{ y: [0, -5, 0] }}
            transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY }}
          >
            <Link href="/" className="text-4xl font-bold gradient-text hover:opacity-80 transition-opacity">
              SecureAuth
            </Link>
          </motion.div>
          <h2 className="text-5xl font-bold text-white mb-3 text-balance">
            {step === "register" ? "Create Account" : "Verify Email"}
          </h2>
          <p style={{ color: "rgba(0, 212, 255, 0.8)" }} className="text-lg">
            {step === "register" ? (
              <>
                Already have an account?{" "}
                <Link
                  href="/login"
                  className="font-bold hover:text-white underline underline-offset-3 transition-colors"
                  style={{ color: "rgb(0, 212, 255)" }}
                >
                  Sign in
                </Link>
              </>
            ) : (
              `We sent a code to ${registeredEmail}`
            )}
          </p>
        </motion.div>

        <AnimatePresence mode="wait">
          {/* Registration Form */}
          {step === "register" && (
            <motion.form
              key="register-form"
              variants={itemVariants}
              className="card p-8 space-y-6"
              onSubmit={handleSubmit}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              {/* Name Field */}
              <motion.div whileHover={{ y: -2 }} transition={{ duration: 0.3 }}>
                <label
                  className="block text-sm font-semibold mb-3 uppercase tracking-wide"
                  style={{ color: "rgb(0, 212, 255)" }}
                >
                  Full Name
                </label>
                <motion.input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  className={`input-field ${fieldErrors.name ? "ring-2" : ""}`}
                  style={
                    fieldErrors.name ? { borderColor: "rgb(255, 0, 110)", boxShadow: "0 0 0 2px rgb(255, 0, 110)" } : {}
                  }
                  placeholder="John Doe"
                  disabled={loading}
                  whileFocus={{ scale: 1.02 }}
                />
                <AnimatePresence>
                  {fieldErrors.name && (
                    <motion.p
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="mt-2 text-sm flex items-center gap-2 font-medium"
                      style={{ color: "rgb(255, 0, 110)" }}
                    >
                      <AlertCircle size={16} /> {fieldErrors.name}
                    </motion.p>
                  )}
                </AnimatePresence>
              </motion.div>

              {/* Email Field */}
              <motion.div whileHover={{ y: -2 }} transition={{ duration: 0.3 }}>
                <label
                  className="block text-sm font-semibold mb-3 uppercase tracking-wide"
                  style={{ color: "rgb(0, 212, 255)" }}
                >
                  Email Address
                </label>
                <motion.input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className={`input-field ${fieldErrors.email ? "ring-2" : ""}`}
                  style={
                    fieldErrors.email
                      ? { borderColor: "rgb(255, 0, 110)", boxShadow: "0 0 0 2px rgb(255, 0, 110)" }
                      : {}
                  }
                  placeholder="you@example.com"
                  disabled={loading}
                  whileFocus={{ scale: 1.02 }}
                />
                <AnimatePresence>
                  {fieldErrors.email && (
                    <motion.p
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="mt-2 text-sm flex items-center gap-2 font-medium"
                      style={{ color: "rgb(255, 0, 110)" }}
                    >
                      <AlertCircle size={16} /> {fieldErrors.email}
                    </motion.p>
                  )}
                </AnimatePresence>
              </motion.div>

              {/* Password Field */}
              <motion.div whileHover={{ y: -2 }} transition={{ duration: 0.3 }}>
                <label
                  className="block text-sm font-semibold mb-3 uppercase tracking-wide"
                  style={{ color: "rgb(0, 212, 255)" }}
                >
                  Password
                </label>
                <div className="relative">
                  <motion.input
                    type={showPassword ? "text" : "password"}
                    name="password"
                    value={formData.password}
                    onChange={handleChange}
                    className={`input-field pr-12 ${fieldErrors.password ? "ring-2" : ""}`}
                    style={
                      fieldErrors.password
                        ? { borderColor: "rgb(255, 0, 110)", boxShadow: "0 0 0 2px rgb(255, 0, 110)" }
                        : {}
                    }
                    placeholder="Create a strong password"
                    disabled={loading}
                    whileFocus={{ scale: 1.02 }}
                  />
                  <motion.button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 hover:text-white transition-colors"
                    style={{ color: "rgb(0, 212, 255)" }}
                    disabled={loading}
                    whileHover={{ scale: 1.2 }}
                    whileTap={{ scale: 0.9 }}
                  >
                    {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                  </motion.button>
                </div>
                <AnimatePresence>
                  {fieldErrors.password && (
                    <motion.p
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="mt-2 text-sm flex items-center gap-2 font-medium"
                      style={{ color: "rgb(255, 0, 110)" }}
                    >
                      <AlertCircle size={16} /> {fieldErrors.password}
                    </motion.p>
                  )}
                </AnimatePresence>
              </motion.div>

              {/* Submit Button */}
              <motion.button
                type="submit"
                disabled={loading}
                className="btn-primary w-full inline-flex items-center justify-center gap-2 mt-8 text-lg"
                whileHover={{ y: -3, scale: 1.02 }}
                whileTap={{ scale: 0.95 }}
              >
                {loading ? (
                  <>
                    <Loader size={20} className="spinner" />
                    Creating account...
                  </>
                ) : (
                  <>
                    <CheckCircle2 size={20} />
                    Create Account
                  </>
                )}
              </motion.button>
            </motion.form>
          )}

          {/* Verification Form */}
          {step === "verify" && (
            <motion.form
              key="verify-form"
              variants={itemVariants}
              className="card p-8 space-y-6"
              onSubmit={handleVerification}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <motion.div className="text-center mb-8">
                <Mail size={48} className="mx-auto mb-4" style={{ color: "rgb(0, 212, 255)" }} />
                <p className="text-white opacity-80">
                  A verification code has been sent to your email address. Please enter it below.
                </p>
              </motion.div>

              <motion.div whileHover={{ y: -2 }} transition={{ duration: 0.3 }}>
                <label
                  className="block text-sm font-semibold mb-3 uppercase tracking-wide"
                  style={{ color: "rgb(0, 212, 255)" }}
                >
                  Verification Code
                </label>
                <motion.input
                  type="text"
                  value={verificationCode}
                  onChange={(e) => {
                    setVerificationCode(e.target.value.toUpperCase())
                    if (fieldErrors.code) {
                      setFieldErrors((prev) => ({ ...prev, code: "" }))
                    }
                  }}
                  className={`input-field text-center text-2xl tracking-widest ${fieldErrors.code ? "ring-2" : ""}`}
                  style={
                    fieldErrors.code ? { borderColor: "rgb(255, 0, 110)", boxShadow: "0 0 0 2px rgb(255, 0, 110)" } : {}
                  }
                  placeholder="000000"
                  maxLength={6}
                  disabled={loading}
                  whileFocus={{ scale: 1.02 }}
                />
                <AnimatePresence>
                  {fieldErrors.code && (
                    <motion.p
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="mt-2 text-sm flex items-center gap-2 font-medium"
                      style={{ color: "rgb(255, 0, 110)" }}
                    >
                      <AlertCircle size={16} /> {fieldErrors.code}
                    </motion.p>
                  )}
                </AnimatePresence>
              </motion.div>

              <motion.button
                type="submit"
                disabled={loading}
                className="btn-primary w-full inline-flex items-center justify-center gap-2 mt-8 text-lg"
                whileHover={{ y: -3, scale: 1.02 }}
                whileTap={{ scale: 0.95 }}
              >
                {loading ? (
                  <>
                    <Loader size={20} className="spinner" />
                    Verifying...
                  </>
                ) : (
                  <>
                    <CheckCircle2 size={20} />
                    Verify Email
                  </>
                )}
              </motion.button>

              <motion.button
                type="button"
                onClick={() => {
                  setStep("register")
                  setVerificationCode("")
                }}
                className="w-full px-6 py-2 text-sm font-semibold transition-all border rounded-lg"
                style={{
                  borderColor: "rgba(0, 212, 255, 0.3)",
                  color: "rgb(0, 212, 255)",
                }}
                whileHover={{ backgroundColor: "rgba(0, 212, 255, 0.1)" }}
              >
                Back to Registration
              </motion.button>
            </motion.form>
          )}
        </AnimatePresence>

        <motion.p
          variants={itemVariants}
          className="text-center text-sm mt-8 font-medium"
          style={{ color: "rgba(0, 212, 255, 0.6)" }}
        >
          By signing up, you agree to our Terms and Privacy Policy
        </motion.p>
      </motion.div>
    </div>
  )
}
