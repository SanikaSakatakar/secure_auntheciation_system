"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import { LogOut, Mail, User, Sparkles, BarChart3, Lock, Settings, Moon, Sun, Upload } from "lucide-react"
import { toast, Toaster } from "react-hot-toast"
import Link from "next/link"
import { useTheme } from "@/lib/theme-provider"

interface UserData {
  name: string
  email: string
  password: string
  avatar?: string
}

export default function Dashboard() {
  const [user, setUser] = useState<UserData | null>(null)
  const [loading, setLoading] = useState(true)
  const [isEditing, setIsEditing] = useState(false)
  const [editName, setEditName] = useState("")
  const [mounted, setMounted] = useState(false)
  const [accountCreatedDate] = useState<string>(() => {
    const date = new Date()
    return date.toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })
  })
  const { theme, toggleTheme } = useTheme()

  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    if (!mounted) return

    const isLoggedIn = localStorage.getItem("isLoggedIn")
    const token = localStorage.getItem("token")
    const currentUser = localStorage.getItem("currentUser")

    if (!isLoggedIn || !token || !currentUser) {
      window.location.href = "/login"
      return
    }

    try {
      const userData = JSON.parse(currentUser)
      setUser(userData)
      setEditName(userData.name)
    } catch (error) {
      console.log("[v0] Error parsing user data:", error)
      window.location.href = "/login"
    } finally {
      setLoading(false)
    }
  }, [mounted])

  const handleLogout = () => {
    localStorage.removeItem("isLoggedIn")
    localStorage.removeItem("currentUser")
    localStorage.removeItem("token")
    toast.success("Logged out successfully", {
      duration: 2000,
    })
    setTimeout(() => {
      window.location.href = "/"
    }, 1000)
  }

  const handleUpdateProfile = () => {
    if (!editName.trim()) {
      toast.error("Name cannot be empty", {
        duration: 2000,
      })
      return
    }

    const users = JSON.parse(localStorage.getItem("users") || "[]")
    const userIndex = users.findIndex((u: UserData) => u.email === user?.email)

    if (userIndex !== -1) {
      users[userIndex].name = editName
      localStorage.setItem("users", JSON.stringify(users))
      localStorage.setItem("currentUser", JSON.stringify({ ...user, name: editName }))
      setUser({ ...user, name: editName })
      setIsEditing(false)
      toast.success("Profile updated successfully", {
        duration: 2000,
      })
    }
  }

  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onloadend = () => {
      const base64 = reader.result as string
      const users = JSON.parse(localStorage.getItem("users") || "[]")
      const userIndex = users.findIndex((u: UserData) => u.email === user?.email)

      if (userIndex !== -1) {
        users[userIndex].avatar = base64
        localStorage.setItem("users", JSON.stringify(users))
        localStorage.setItem("currentUser", JSON.stringify({ ...user, avatar: base64 }))
        setUser({ ...user, avatar: base64 })
        toast.success("Avatar updated successfully", { duration: 2000 })
      }
    }
    reader.readAsDataURL(file)
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  }

  if (!mounted || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: "#0a0e27" }}>
        <motion.div animate={{ rotate: 360 }} transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}>
          <div
            className="w-12 h-12 rounded-full border-4 border-transparent"
            style={{
              borderTopColor: "rgb(109, 92, 255)",
              borderRightColor: "rgb(0, 212, 255)",
              animation: "spin 1s linear infinite",
            }}
          />
        </motion.div>
      </div>
    )
  }

  return (
    <div className="min-h-screen relative overflow-hidden" style={{ backgroundColor: "#0a0e27" }}>
      {/* Background blobs */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          className="absolute w-96 h-96 rounded-full blur-3xl"
          animate={{ y: [0, 60, 0], x: [0, 40, 0] }}
          transition={{ duration: 20, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
          style={{
            top: "-150px",
            left: "-150px",
            background: "linear-gradient(135deg, rgba(109, 92, 255, 0.15), rgba(0, 212, 255, 0.15))",
          }}
        />
        <motion.div
          className="absolute w-96 h-96 rounded-full blur-3xl"
          animate={{ y: [60, 0, 60], x: [40, 0, 40] }}
          transition={{ duration: 20, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut", delay: 3 }}
          style={{
            bottom: "-150px",
            right: "-150px",
            background: "linear-gradient(135deg, rgba(255, 0, 110, 0.15), rgba(131, 56, 236, 0.15))",
          }}
        />
      </div>

      <Toaster position="top-center" reverseOrder={false} />

      {/* Navigation Header */}
      <motion.header
        className="relative z-10 border-b backdrop-blur-md"
        style={{
          borderColor: "rgba(45, 53, 97, 0.5)",
          background: "rgba(26, 31, 58, 0.8)",
        }}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.6 }}
      >
        <div className="max-w-7xl mx-auto px-6 py-6 flex justify-between items-center">
          <div className="flex items-center gap-4">
            <motion.div whileHover={{ scale: 1.05 }}>
              <Link href="/" className="text-3xl font-bold gradient-text hover:opacity-80 transition-opacity">
                SecureAuth
              </Link>
            </motion.div>
            <motion.div
              className="hidden sm:block text-sm"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
            >
              <Link
                href="/"
                className="px-3 py-1 rounded border transition-all"
                style={{
                  borderColor: "rgba(0, 212, 255, 0.3)",
                  color: "rgb(0, 212, 255)",
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.borderColor = "rgba(0, 212, 255, 0.6)"
                  e.currentTarget.style.backgroundColor = "rgba(0, 212, 255, 0.1)"
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.borderColor = "rgba(0, 212, 255, 0.3)"
                  e.currentTarget.style.backgroundColor = "transparent"
                }}
              >
                ← Home
              </Link>
            </motion.div>
          </div>
          <div className="flex items-center gap-4">
            {/* Theme Toggle Button */}
            <motion.button
              onClick={toggleTheme}
              className="p-2 rounded-lg transition-all"
              style={{
                background: "rgba(109, 92, 255, 0.2)",
                borderColor: "rgba(109, 92, 255, 0.3)",
                border: "1px solid",
              }}
              whileHover={{ scale: 1.1, background: "rgba(109, 92, 255, 0.4)" }}
              whileTap={{ scale: 0.9 }}
              title={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}
            >
              {theme === "dark" ? (
                <Sun size={20} style={{ color: "rgb(255, 193, 7)" }} />
              ) : (
                <Moon size={20} style={{ color: "rgb(109, 92, 255)" }} />
              )}
            </motion.button>
            <span className="text-white opacity-70">{user?.name}</span>
            <motion.button
              onClick={handleLogout}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-lg font-semibold transition-all"
              style={{
                background: "linear-gradient(135deg, rgb(255, 0, 110), rgb(255, 80, 140))",
                color: "white",
                boxShadow: "0 0 20px rgba(255, 0, 110, 0.5)",
              }}
              whileHover={{ scale: 1.05, boxShadow: "0 0 30px rgba(255, 0, 110, 0.8)" }}
              whileTap={{ scale: 0.95 }}
            >
              <LogOut size={20} />
              Logout
            </motion.button>
          </div>
        </div>
      </motion.header>

      {/* Main Content */}
      <motion.main
        className="max-w-7xl mx-auto px-6 py-12 relative z-10"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Welcome Section */}
        <motion.div variants={itemVariants} className="mb-12">
          <h2 className="text-5xl font-bold text-white mb-3 text-balance flex items-center gap-3">
            <Sparkles size={40} style={{ color: "rgb(0, 212, 255)" }} />
            Welcome, {user?.name}!
          </h2>
          <p style={{ color: "rgba(0, 212, 255, 0.7)" }} className="text-lg">
            Manage your account, security settings, and personal preferences from your dashboard.
          </p>
        </motion.div>

        {/* Avatar Section */}
        <motion.div variants={itemVariants} className="mb-12">
          <motion.div
            className="w-32 h-32 rounded-full border-4 flex items-center justify-center cursor-pointer relative group"
            style={{
              borderColor: "rgba(0, 212, 255, 0.5)",
              background: user?.avatar
                ? "transparent"
                : "linear-gradient(135deg, rgba(109, 92, 255, 0.2), rgba(0, 212, 255, 0.2))",
            }}
            whileHover={{ scale: 1.05 }}
          >
            {user?.avatar ? (
              <img
                src={user.avatar || "/placeholder.svg"}
                alt="Profile"
                className="w-full h-full rounded-full object-cover"
              />
            ) : (
              <User size={48} style={{ color: "rgb(0, 212, 255)" }} />
            )}
            <label
              htmlFor="avatar-upload"
              className="absolute bottom-0 right-0 p-2 rounded-full transition-all cursor-pointer"
              style={{
                background: "linear-gradient(135deg, rgb(109, 92, 255), rgb(0, 212, 255))",
              }}
            >
              <Upload size={20} color="white" />
              <input type="file" id="avatar-upload" className="hidden" accept="image/*" onChange={handleAvatarUpload} />
            </label>
          </motion.div>
        </motion.div>

        {/* Stats Overview */}
        <motion.div variants={itemVariants} className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          {[
            { label: "Account Status", value: "Active", icon: "🟢", color: "#00d4ff" },
            { label: "Member Since", value: accountCreatedDate, icon: "📅", color: "#6d5cff" },
            { label: "Security Level", value: "Premium", icon: "🔒", color: "#ff006e" },
            { label: "Sessions Active", value: "1", icon: "📱", color: "#00d4ff" },
          ].map((stat, i) => (
            <motion.div
              key={i}
              className="rounded-lg p-4 text-center border transition-all"
              style={{
                background: `rgba(${stat.color === "#00d4ff" ? "0, 212, 255" : stat.color === "#6d5cff" ? "109, 92, 255" : "255, 0, 110"}, 0.08)`,
                borderColor: `rgba(${stat.color === "#00d4ff" ? "0, 212, 255" : stat.color === "#6d5cff" ? "109, 92, 255" : "255, 0, 110"}, 0.3)`,
              }}
              whileHover={{ y: -4, scale: 1.02 }}
              transition={{ duration: 0.3 }}
            >
              <div className="text-3xl mb-2">{stat.icon}</div>
              <p className="text-xs font-semibold uppercase tracking-wide" style={{ color: stat.color }}>
                {stat.label}
              </p>
              <p className="text-lg font-bold text-white mt-2">{stat.value}</p>
            </motion.div>
          ))}
        </motion.div>

        {/* User Information Section */}
        <motion.div variants={itemVariants} className="grid md:grid-cols-2 gap-6 mb-12">
          {/* Email Card */}
          <motion.div
            className="rounded-lg p-8 border transition-all group"
            style={{
              background: "rgba(0, 212, 255, 0.08)",
              borderColor: "rgba(0, 212, 255, 0.3)",
            }}
            whileHover={{ y: -5, boxShadow: "0 0 30px rgba(0, 212, 255, 0.2)" }}
            transition={{ duration: 0.3 }}
          >
            <div className="flex items-center gap-4 mb-6">
              <div
                className="p-3 rounded-lg group-hover:scale-110 transition-transform"
                style={{
                  background: "linear-gradient(135deg, rgba(0, 212, 255, 0.2), rgba(109, 92, 255, 0.2))",
                }}
              >
                <Mail size={24} style={{ color: "rgb(0, 212, 255)" }} />
              </div>
              <span className="text-sm font-semibold uppercase tracking-wide" style={{ color: "rgb(0, 212, 255)" }}>
                Email Address
              </span>
            </div>
            <p className="text-2xl font-bold text-white break-all">{user?.email}</p>
          </motion.div>

          {/* Profile Card */}
          <motion.div
            className="rounded-lg p-8 border transition-all group"
            style={{
              background: "rgba(255, 0, 110, 0.08)",
              borderColor: "rgba(255, 0, 110, 0.3)",
            }}
            whileHover={{ y: -5, boxShadow: "0 0 30px rgba(255, 0, 110, 0.2)" }}
            transition={{ duration: 0.3 }}
          >
            <div className="flex items-center gap-4 mb-6">
              <div
                className="p-3 rounded-lg group-hover:scale-110 transition-transform"
                style={{
                  background: "linear-gradient(135deg, rgba(255, 0, 110, 0.2), rgba(131, 56, 236, 0.2))",
                }}
              >
                <User size={24} style={{ color: "rgb(255, 0, 110)" }} />
              </div>
              <span className="text-sm font-semibold uppercase tracking-wide" style={{ color: "rgb(255, 0, 110)" }}>
                Full Name
              </span>
            </div>
            <p className="text-2xl font-bold text-white">{user?.name}</p>
          </motion.div>
        </motion.div>

        {/* Edit Profile */}
        <motion.div
          variants={itemVariants}
          className="rounded-lg p-8 mb-12 border"
          style={{
            background: "rgba(109, 92, 255, 0.08)",
            borderColor: "rgba(109, 92, 255, 0.3)",
          }}
        >
          <h3 className="text-2xl font-bold text-white mb-8 flex items-center gap-2">
            <User size={28} style={{ color: "rgb(109, 92, 255)" }} />
            Update Your Profile
          </h3>

          <div className="space-y-6">
            <div>
              <label
                className="block text-sm font-semibold mb-3 uppercase tracking-wide"
                style={{ color: "rgb(109, 92, 255)" }}
              >
                Full Name
              </label>
              {isEditing ? (
                <motion.input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full rounded-lg px-4 py-3 border transition-all"
                  style={{
                    background: "rgba(109, 92, 255, 0.1)",
                    borderColor: "rgba(109, 92, 255, 0.5)",
                    color: "white",
                  }}
                  whileFocus={{ scale: 1.02 }}
                  autoFocus
                />
              ) : (
                <p className="text-lg text-white opacity-80">{user?.name}</p>
              )}
            </div>

            <div className="flex gap-4 pt-4">
              {isEditing ? (
                <>
                  <motion.button
                    onClick={handleUpdateProfile}
                    className="px-8 py-3 rounded-lg font-semibold transition-all"
                    style={{
                      background: "linear-gradient(135deg, rgb(109, 92, 255), rgb(0, 212, 255))",
                      color: "white",
                      boxShadow: "0 0 20px rgba(109, 92, 255, 0.5)",
                    }}
                    whileHover={{ y: -2, scale: 1.02, boxShadow: "0 0 30px rgba(109, 92, 255, 0.8)" }}
                    whileTap={{ scale: 0.95 }}
                  >
                    Save Changes
                  </motion.button>
                  <motion.button
                    onClick={() => {
                      setIsEditing(false)
                      setEditName(user?.name || "")
                    }}
                    className="px-8 py-3 rounded-lg font-semibold transition-all border"
                    style={{
                      borderColor: "rgba(0, 212, 255, 0.5)",
                      color: "rgb(0, 212, 255)",
                      backgroundColor: "rgba(0, 212, 255, 0.1)",
                    }}
                    whileHover={{ backgroundColor: "rgba(0, 212, 255, 0.2)" }}
                    whileTap={{ scale: 0.95 }}
                  >
                    Cancel
                  </motion.button>
                </>
              ) : (
                <motion.button
                  onClick={() => setIsEditing(true)}
                  className="px-8 py-3 rounded-lg font-semibold transition-all border"
                  style={{
                    borderColor: "rgba(109, 92, 255, 0.5)",
                    color: "rgb(109, 92, 255)",
                    backgroundColor: "rgba(109, 92, 255, 0.1)",
                  }}
                  whileHover={{ backgroundColor: "rgba(109, 92, 255, 0.2)" }}
                  whileTap={{ scale: 0.95 }}
                >
                  Edit Profile
                </motion.button>
              )}
            </div>
          </div>
        </motion.div>

        {/* Activity & Settings */}
        <motion.div variants={itemVariants} className="grid md:grid-cols-2 gap-6 mb-12">
          {/* Recent Activity */}
          <motion.div
            className="rounded-lg p-8 border"
            style={{
              background: "rgba(0, 212, 255, 0.08)",
              borderColor: "rgba(0, 212, 255, 0.3)",
            }}
            whileHover={{ y: -5 }}
            transition={{ duration: 0.3 }}
          >
            <h3 className="font-bold text-lg text-white mb-6 flex items-center gap-2">
              <BarChart3 size={24} style={{ color: "rgb(0, 212, 255)" }} />
              Recent Activity
            </h3>
            <div className="space-y-4">
              <div
                className="flex items-center gap-3 p-3 rounded-lg"
                style={{ backgroundColor: "rgba(0, 212, 255, 0.1)" }}
              >
                <span className="text-xl">✓</span>
                <div>
                  <p className="text-sm font-semibold text-white">Account Created</p>
                  <p style={{ color: "rgba(0, 212, 255, 0.6)" }} className="text-xs">
                    Today
                  </p>
                </div>
              </div>
              <div
                className="flex items-center gap-3 p-3 rounded-lg"
                style={{ backgroundColor: "rgba(109, 92, 255, 0.1)" }}
              >
                <span className="text-xl">🔐</span>
                <div>
                  <p className="text-sm font-semibold text-white">Verified Email</p>
                  <p style={{ color: "rgba(109, 92, 255, 0.6)" }} className="text-xs">
                    Automatic
                  </p>
                </div>
              </div>
              <div
                className="flex items-center gap-3 p-3 rounded-lg"
                style={{ backgroundColor: "rgba(255, 0, 110, 0.1)" }}
              >
                <span className="text-xl">🌐</span>
                <div>
                  <p className="text-sm font-semibold text-white">Logged In</p>
                  <p style={{ color: "rgba(255, 0, 110, 0.6)" }} className="text-xs">
                    Just now
                  </p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Security Settings */}
          <motion.div
            className="rounded-lg p-8 border"
            style={{
              background: "rgba(255, 0, 110, 0.08)",
              borderColor: "rgba(255, 0, 110, 0.3)",
            }}
            whileHover={{ y: -5 }}
            transition={{ duration: 0.3 }}
          >
            <h3 className="font-bold text-lg text-white mb-6 flex items-center gap-2">
              <Settings size={24} style={{ color: "rgb(255, 0, 110)" }} />
              Security Settings
            </h3>
            <div className="space-y-3">
              <label
                className="flex items-center gap-3 cursor-pointer p-3 rounded-lg hover:bg-opacity-70 transition"
                style={{ backgroundColor: "rgba(0, 212, 255, 0.05)" }}
              >
                <input type="checkbox" defaultChecked className="w-4 h-4 rounded" />
                <span className="text-sm font-semibold text-white">Two-Factor Authentication</span>
              </label>
              <label
                className="flex items-center gap-3 cursor-pointer p-3 rounded-lg hover:bg-opacity-70 transition"
                style={{ backgroundColor: "rgba(255, 0, 110, 0.05)" }}
              >
                <input type="checkbox" defaultChecked className="w-4 h-4 rounded" />
                <span className="text-sm font-semibold text-white">Email Notifications</span>
              </label>
              <label
                className="flex items-center gap-3 cursor-pointer p-3 rounded-lg hover:bg-opacity-70 transition"
                style={{ backgroundColor: "rgba(109, 92, 255, 0.05)" }}
              >
                <input type="checkbox" className="w-4 h-4 rounded" />
                <span className="text-sm font-semibold text-white">Marketing Updates</span>
              </label>
            </div>
          </motion.div>
        </motion.div>

        {/* Password & Account Management */}
        <motion.div variants={itemVariants} className="grid md:grid-cols-2 gap-6 mb-12">
          {/* Password Management */}
          <motion.div
            className="rounded-lg p-8 border"
            style={{
              background: "rgba(131, 56, 236, 0.08)",
              borderColor: "rgba(131, 56, 236, 0.3)",
            }}
            whileHover={{ y: -5 }}
            transition={{ duration: 0.3 }}
          >
            <h3 className="font-bold text-lg text-white mb-6 flex items-center gap-2">
              <Lock size={24} style={{ color: "rgb(131, 56, 236)" }} />
              Password Management
            </h3>
            <p className="text-sm opacity-70 text-white mb-6">
              Secure your account by changing your password regularly.
            </p>
            <motion.button
              className="w-full px-6 py-3 rounded-lg font-semibold transition-all border"
              style={{
                borderColor: "rgba(131, 56, 236, 0.5)",
                color: "rgb(131, 56, 236)",
                backgroundColor: "rgba(131, 56, 236, 0.1)",
              }}
              whileHover={{ backgroundColor: "rgba(131, 56, 236, 0.2)" }}
              whileTap={{ scale: 0.95 }}
            >
              Change Password
            </motion.button>
          </motion.div>

          {/* Connected Devices */}
          <motion.div
            className="rounded-lg p-8 border"
            style={{
              background: "rgba(109, 92, 255, 0.08)",
              borderColor: "rgba(109, 92, 255, 0.3)",
            }}
            whileHover={{ y: -5 }}
            transition={{ duration: 0.3 }}
          >
            <h3 className="font-bold text-lg text-white mb-6 flex items-center gap-2">
              <span className="text-2xl">📱</span>
              Connected Devices
            </h3>
            <div className="space-y-3">
              <div
                className="flex items-center justify-between p-3 rounded-lg"
                style={{ backgroundColor: "rgba(109, 92, 255, 0.1)" }}
              >
                <div>
                  <p className="text-sm font-semibold text-white">Current Device</p>
                  <p className="text-xs opacity-60 text-white">Browser · Active now</p>
                </div>
                <span className="text-green-400">●</span>
              </div>
            </div>
          </motion.div>
        </motion.div>

        {/* Preferences & Notifications */}
        <motion.div
          variants={itemVariants}
          className="rounded-lg p-8 mb-12 border"
          style={{
            background: "rgba(0, 212, 255, 0.08)",
            borderColor: "rgba(0, 212, 255, 0.3)",
          }}
        >
          <h3 className="font-bold text-lg text-white mb-6 flex items-center gap-2">
            <span className="text-2xl">🔔</span>
            Notification Preferences
          </h3>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <h4 className="text-sm font-semibold text-white opacity-80">Email Notifications</h4>
              <label className="flex items-center gap-3 cursor-pointer">
                <input type="checkbox" defaultChecked className="w-4 h-4 rounded" />
                <span className="text-sm text-white">Security Alerts</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer">
                <input type="checkbox" defaultChecked className="w-4 h-4 rounded" />
                <span className="text-sm text-white">Login Notifications</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer">
                <input type="checkbox" className="w-4 h-4 rounded" />
                <span className="text-sm text-white">Weekly Digest</span>
              </label>
            </div>
            <div className="space-y-3">
              <h4 className="text-sm font-semibold text-white opacity-80">Activity</h4>
              <label className="flex items-center gap-3 cursor-pointer">
                <input type="checkbox" defaultChecked className="w-4 h-4 rounded" />
                <span className="text-sm text-white">Track Login Attempts</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer">
                <input type="checkbox" defaultChecked className="w-4 h-4 rounded" />
                <span className="text-sm text-white">Session Activity Logs</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer">
                <input type="checkbox" className="w-4 h-4 rounded" />
                <span className="text-sm text-white">Download Data</span>
              </label>
            </div>
          </div>
        </motion.div>

        {/* Security Info Banner */}
        <motion.div
          variants={itemVariants}
          className="p-8 rounded-lg border"
          style={{
            borderColor: "rgba(0, 212, 255, 0.3)",
            background: "rgba(0, 212, 255, 0.05)",
          }}
        >
          <h3 className="font-bold text-lg text-white mb-4 flex items-center gap-2">
            <Lock size={24} style={{ color: "rgb(0, 212, 255)" }} />
            Security Information
          </h3>
          <ul className="space-y-3 text-sm opacity-80" style={{ color: "rgb(0, 212, 255)" }}>
            <li className="flex items-start gap-3">
              <span className="text-base leading-6">✓</span>
              <span>Your credentials are stored securely with encryption protocols</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-base leading-6">✓</span>
              <span>Session data is validated on every action for maximum security</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-base leading-6">✓</span>
              <span>All transactions are protected with industry-standard encryption</span>
            </li>
          </ul>
        </motion.div>
      </motion.main>
    </div>
  )
}
