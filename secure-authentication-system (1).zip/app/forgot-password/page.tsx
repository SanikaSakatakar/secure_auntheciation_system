"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import Link from "next/link"
import { Mail, Loader, AlertCircle, CheckCircle2, ArrowRight } from "lucide-react"
import { toast, Toaster } from "react-hot-toast"

export default function ForgotPassword() {
  const [email, setEmail] = useState("")
  const [loading, setLoading] = useState(false)
  const [step, setStep] = useState<"email" | "reset" | "success">("email")
  const [resetCode, setResetCode] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [mounted, setMounted] = useState(false)
  const [generatedCode, setGeneratedCode] = useState("")
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({})

  useEffect(() => {
    setMounted(true)
  }, [])

  const validateEmail = (emailToCheck: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailToCheck)
  }

  const handleEmailSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const errors: Record<string, string> = {}

    if (!email.trim()) {
      errors.email = "Email is required"
    } else if (!validateEmail(email)) {
      errors.email = "Please enter a valid email"
    } else {
      const users = JSON.parse(localStorage.getItem("users") || "[]")
      const userExists = users.some((u: any) => u.email === email)
      if (!userExists) {
        errors.email = "Email not found in our system"
      }
    }

    setFieldErrors(errors)
    if (Object.keys(errors).length > 0) return

    setLoading(true)
    await new Promise((resolve) => setTimeout(resolve, 1000))

    const code = Math.random().toString(36).substring(2, 8).toUpperCase()
    setGeneratedCode(code)
    localStorage.setItem(`reset_${email}`, code)

    toast.success("Reset code sent to your email", {
      duration: 3000,
      icon: <CheckCircle2 className="w-5 h-5" />,
    })

    setStep("reset")
    setLoading(false)
  }

  const handleResetCodeSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const errors: Record<string, string> = {}

    if (!resetCode.trim()) {
      errors.code = "Reset code is required"
    } else if (resetCode !== generatedCode) {
      errors.code = "Invalid reset code"
    }

    if (!newPassword.trim()) {
      errors.password = "New password is required"
    } else if (newPassword.length < 6) {
      errors.password = "Password must be at least 6 characters"
    }

    setFieldErrors(errors)
    if (Object.keys(errors).length > 0) return

    const users = JSON.parse(localStorage.getItem("users") || "[]")
    const userIndex = users.findIndex((u: any) => u.email === email)

    if (userIndex !== -1) {
      users[userIndex].password = newPassword
      localStorage.setItem("users", JSON.stringify(users))
      localStorage.removeItem(`reset_${email}`)

      toast.success("Password reset successfully! Redirecting to login...", {
        duration: 2000,
        icon: <CheckCircle2 className="w-5 h-5" />,
      })

      setTimeout(() => {
        window.location.href = "/login"
      }, 2000)
    }
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
        delayChildren: 0.3,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6, ease: "easeOut" },
    },
  }

  if (!mounted) return null

  return (
    <div
      className="min-h-screen flex items-center justify-center px-4 py-8 relative overflow-hidden"
      style={{ backgroundColor: "#0a0e27" }}
    >
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          className="absolute w-96 h-96 rounded-full blur-3xl"
          animate={{ y: [0, 60, 0], x: [0, 40, 0] }}
          transition={{ duration: 20, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
          style={{
            top: "-150px",
            left: "-150px",
            background: "linear-gradient(135deg, rgba(109, 92, 255, 0.2), rgba(0, 212, 255, 0.2))",
          }}
        />
        <motion.div
          className="absolute w-96 h-96 rounded-full blur-3xl"
          animate={{ y: [60, 0, 60], x: [40, 0, 40] }}
          transition={{ duration: 20, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut", delay: 3 }}
          style={{
            bottom: "-150px",
            right: "-150px",
            background: "linear-gradient(135deg, rgba(255, 0, 110, 0.2), rgba(131, 56, 236, 0.2))",
          }}
        />
      </div>

      <Toaster position="top-center" reverseOrder={false} />

      <motion.div
        className="w-full max-w-md relative z-10"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.div
          className="absolute -top-16 right-0"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
        >
          <Link
            href="/login"
            className="text-sm font-semibold px-4 py-2 rounded-lg transition-all border"
            style={{
              borderColor: "rgba(0, 212, 255, 0.4)",
              color: "rgb(0, 212, 255)",
              backgroundColor: "rgba(0, 212, 255, 0.08)",
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = "rgba(0, 212, 255, 0.16)"
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = "rgba(0, 212, 255, 0.08)"
            }}
          >
            ← Back to Login
          </Link>
        </motion.div>

        <motion.div variants={itemVariants} className="text-center mb-10">
          <motion.div
            className="inline-block mb-6"
            whileHover={{ scale: 1.08 }}
            whileTap={{ scale: 0.95 }}
            animate={{ y: [0, -5, 0] }}
            transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY }}
          >
            <Link href="/" className="text-4xl font-bold gradient-text hover:opacity-80 transition-opacity">
              SecureAuth
            </Link>
          </motion.div>
          <h2 className="text-5xl font-bold text-white mb-3 text-balance">Reset Password</h2>
          <p style={{ color: "rgba(0, 212, 255, 0.8)" }} className="text-lg">
            {step === "email"
              ? "Enter your email to receive a reset code"
              : step === "reset"
                ? "Enter the reset code and your new password"
                : "Your password has been reset successfully"}
          </p>
        </motion.div>

        <AnimatePresence mode="wait">
          {/* Email Step */}
          {step === "email" && (
            <motion.form
              key="email-form"
              variants={itemVariants}
              className="card p-8 space-y-6"
              onSubmit={handleEmailSubmit}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <motion.div whileHover={{ y: -2 }} transition={{ duration: 0.3 }}>
                <label
                  className="block text-sm font-semibold mb-3 uppercase tracking-wide"
                  style={{ color: "rgb(0, 212, 255)" }}
                >
                  Email Address
                </label>
                <motion.input
                  type="email"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value)
                    if (fieldErrors.email) {
                      setFieldErrors((prev) => ({ ...prev, email: "" }))
                    }
                  }}
                  className="input-field"
                  style={fieldErrors.email ? { borderColor: "rgb(255, 0, 110)" } : {}}
                  placeholder="your@email.com"
                  disabled={loading}
                  whileFocus={{ scale: 1.02 }}
                />
                <AnimatePresence>
                  {fieldErrors.email && (
                    <motion.p
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="mt-2 text-sm flex items-center gap-2 font-medium"
                      style={{ color: "rgb(255, 0, 110)" }}
                    >
                      <AlertCircle size={16} /> {fieldErrors.email}
                    </motion.p>
                  )}
                </AnimatePresence>
              </motion.div>

              <motion.button
                type="submit"
                disabled={loading}
                className="btn-primary w-full inline-flex items-center justify-center gap-2 mt-8 text-lg"
                whileHover={{ y: -3, scale: 1.02 }}
                whileTap={{ scale: 0.95 }}
              >
                {loading ? (
                  <>
                    <Loader size={20} className="spinner" />
                    Sending Code...
                  </>
                ) : (
                  <>
                    <Mail size={20} />
                    Send Reset Code
                  </>
                )}
              </motion.button>
            </motion.form>
          )}

          {/* Reset Code Step */}
          {step === "reset" && (
            <motion.form
              key="reset-form"
              variants={itemVariants}
              className="card p-8 space-y-6"
              onSubmit={handleResetCodeSubmit}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <motion.div whileHover={{ y: -2 }} transition={{ duration: 0.3 }}>
                <label
                  className="block text-sm font-semibold mb-3 uppercase tracking-wide"
                  style={{ color: "rgb(0, 212, 255)" }}
                >
                  Reset Code
                </label>
                <motion.input
                  type="text"
                  value={resetCode}
                  onChange={(e) => {
                    setResetCode(e.target.value.toUpperCase())
                    if (fieldErrors.code) {
                      setFieldErrors((prev) => ({ ...prev, code: "" }))
                    }
                  }}
                  className="input-field"
                  style={fieldErrors.code ? { borderColor: "rgb(255, 0, 110)" } : {}}
                  placeholder="Enter 6-digit code"
                  maxLength={6}
                  whileFocus={{ scale: 1.02 }}
                />
                <AnimatePresence>
                  {fieldErrors.code && (
                    <motion.p
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="mt-2 text-sm flex items-center gap-2 font-medium"
                      style={{ color: "rgb(255, 0, 110)" }}
                    >
                      <AlertCircle size={16} /> {fieldErrors.code}
                    </motion.p>
                  )}
                </AnimatePresence>
              </motion.div>

              <motion.div whileHover={{ y: -2 }} transition={{ duration: 0.3 }}>
                <label
                  className="block text-sm font-semibold mb-3 uppercase tracking-wide"
                  style={{ color: "rgb(0, 212, 255)" }}
                >
                  New Password
                </label>
                <motion.input
                  type="password"
                  value={newPassword}
                  onChange={(e) => {
                    setNewPassword(e.target.value)
                    if (fieldErrors.password) {
                      setFieldErrors((prev) => ({ ...prev, password: "" }))
                    }
                  }}
                  className="input-field"
                  style={fieldErrors.password ? { borderColor: "rgb(255, 0, 110)" } : {}}
                  placeholder="Create new password"
                  whileFocus={{ scale: 1.02 }}
                />
                <AnimatePresence>
                  {fieldErrors.password && (
                    <motion.p
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="mt-2 text-sm flex items-center gap-2 font-medium"
                      style={{ color: "rgb(255, 0, 110)" }}
                    >
                      <AlertCircle size={16} /> {fieldErrors.password}
                    </motion.p>
                  )}
                </AnimatePresence>
              </motion.div>

              <motion.button
                type="submit"
                className="btn-primary w-full inline-flex items-center justify-center gap-2 mt-8 text-lg"
                whileHover={{ y: -3, scale: 1.02 }}
                whileTap={{ scale: 0.95 }}
              >
                <ArrowRight size={20} />
                Reset Password
              </motion.button>
            </motion.form>
          )}
        </AnimatePresence>

        <motion.p
          variants={itemVariants}
          className="text-center text-sm mt-8 font-medium"
          style={{ color: "rgba(0, 212, 255, 0.6)" }}
        >
          Remember your password?{" "}
          <Link
            href="/login"
            className="font-bold hover:text-white underline underline-offset-3 transition-colors"
            style={{ color: "rgb(0, 212, 255)" }}
          >
            Sign in
          </Link>
        </motion.p>
      </motion.div>
    </div>
  )
}
