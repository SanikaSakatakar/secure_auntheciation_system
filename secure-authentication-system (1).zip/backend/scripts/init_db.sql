-- Create users table
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create index on email for faster lookups
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

-- Insert sample user for testing (password: password123)
INSERT INTO users (name, email, password_hash) 
VALUES ('Test User', 'test@example.com', '$2b$12$K9h/cIPz0gi.URNNF3kh2OPST9/PgBkqquzi.Ee9O6c/JvY1IFqXi')
ON CONFLICT (email) DO NOTHING;
