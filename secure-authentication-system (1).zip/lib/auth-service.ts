import apiClient from "./api-client"

export interface User {
  id: number
  name: string
  email: string
  created_at: string
}

export interface AuthResponse {
  message: string
  token: string
  user: User
}

export const authService = {
  // Register new user
  async register(name: string, email: string, password: string): Promise<AuthResponse> {
    const response = await apiClient.post<AuthResponse>("/api/auth/register", {
      name,
      email,
      password,
    })
    return response.data
  },

  // Login user
  async login(email: string, password: string): Promise<AuthResponse> {
    const response = await apiClient.post<AuthResponse>("/api/auth/login", {
      email,
      password,
    })
    return response.data
  },

  // Get user profile
  async getProfile(): Promise<{ user: User }> {
    const response = await apiClient.get<{ user: User }>("/api/user/profile")
    return response.data
  },

  // Update user profile
  async updateProfile(name: string): Promise<{ message: string; user: User }> {
    const response = await apiClient.put<{ message: string; user: User }>("/api/user/update-profile", {
      name,
    })
    return response.data
  },

  // Store token and user
  storeAuth(token: string, user: User): void {
    localStorage.setItem("token", token)
    localStorage.setItem("user", JSON.stringify(user))
  },

  // Clear stored auth
  clearAuth(): void {
    localStorage.removeItem("token")
    localStorage.removeItem("user")
  },

  // Get stored token
  getToken(): string | null {
    return typeof window !== "undefined" ? localStorage.getItem("token") : null
  },

  // Get stored user
  getUser(): User | null {
    const user = typeof window !== "undefined" ? localStorage.getItem("user") : null
    return user ? JSON.parse(user) : null
  },
}
